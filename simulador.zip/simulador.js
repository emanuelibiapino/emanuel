$(document).ready(function(){
    $(window).scroll(function(){
        if ($(this).scrollTop() > 100) {
            $('a[href="#top"]').fadeIn();
        } else {
            $('a[href="#top"]').fadeOut();
        }
    });

    $('a[href="#top"]').click(function(){
        $('html, body').animate({scrollTop : 0},800);
        return false;
    });
});

function calcular(){
	var v1 = parseInt(document.getElementById('caixa').value);
	var v2 = parseInt(document.getElementById('banco_movimento').value);
	var v3 = parseInt(document.getElementById('afli').value);
	var disponivel = v1 + v2 + v3;
	document.getElementById('disponivel').value = disponivel;

	var v4 = parseInt(document.getElementById('duplicatas_receber').value);
	var clientes = v4
	document.getElementById('clientes').value = clientes;

	var v5 = parseInt(document.getElementById('adiantamentos_empregados').value);
	var outros_creditos = v5;
	document.getElementById('outros_creditos').value = outros_creditos;

	var v6 = parseInt(document.getElementById('icms_recuperar').value);
	var tributos_recuperar = v6;
	document.getElementById('tributos_recuperar').value = tributos_recuperar;

	var v7 = parseInt(document.getElementById('acoes_outras_empresas').value);
	var itcp = v7
	document.getElementById('investimentos_temp').value = itcp;

	var v8 parseInt(document.getElementById('mercadorias_revenda').value);
	var v9 parseInt(document.getElementById('materias_primas').value);
	var v10	parseInt(document.getElementById('almoxarifado').value);
	var estoques = v8 + v9 + v10;
	document.getElementById('estoques').value = estoques;

	var v11 parseInt(document.getElementById('meveis_utensilios').value);
	var v12 parseInt(document.getElementById('damu').value);
	var v13 parseInt(document.getElementById('instalações').value);
	var v14	parseInt(document.getElementById('dai').value);
	var ativo_imobilizado = (v11 - v12) + (v13 - v14);
	document.getElementById('ativo_imobilizado').value = ativo_imobilizado;

	var v15 parseInt(document.getElementById('fundo_comercio').value);
	var v16	parseInt(document.getElementById('afc').value);
	var intangivel = v15 - v16;
	document.getElementById('intangivel').value = intangivel;

	var ativo_circulante = disponivel + clientes + outros_creditos + tributos_recuperar + itcp + estoques;
	document.getElementById('ativo_circulante').value = ativo_circulante;

	var ativo_nao_circulante = ativo_imobilizado + intangivel;
	document.getElementById('ativo_nao_circulante').value = ativo_nao_circulante;

	var total_ativo = ativo_circulante + ativo_nao_circulante;
	document.getElementById('total_ativo').value = total_ativo;	
}

function calcular1(){
	var n1 parseInt(document.getElementById('fornecedores_nacionais').value);
	var n2 parseInt(document.getElementById('fornecedores_estrangeiros').value);
	var obrigacoes_fornecedores = n1 + n2;
	document.getElementById('obrigacoes_fornecedores').value = obrigacoes_fornecedores;

	var n3 parseInt(document.getElementById('emprestimos_pagar').value);
	var emprestimos_financiamentos = n3;
	document.getElementById('emprestimos_financiamentos').value = emprestimos_financiamentos;

	var n4 parseInt(document.getElementById('icms_recolher').value);
	var tributos_recolher = n4;
	document.getElementById('tributos_recolher').value = tributos_recolher;

	var n5 parseInt(document.getElementById('salarios_pagar').value);
	var n6 parseInt(document.getElementById('inss_recolher').value);
	var n7 parseInt(document.getElementById('fgts_recolher').value);
	var n8 parseInt(document.getElementById('ferias_pagar').value);	
	var otp = n5 + n6 + n7 + n8;
	document.getElementById('otp').value = otp;

	var n9 parseInt(document.getElementById('dividendos_pagar').value);
	var pdll = n9;
	document.getElementById('pdll').value = pdll;

	var n10 parseInt(document.getElementById('contas_pagar').value);
	var outras_obrigacoes = n10;
	document.getElementById('outras_obrigacoes').value = outras_obrigacoes;

	var n11 parseInt(document.getElementById('capital_integralizado').value);
	var capital_social = n11;
	document.getElementById('capital_social').value = capital_social;

	var n12 parseInt(document.getElementById('rcmcs').value);
	var n13 parseInt(document.getElementById('reservas_lucros').value);
	var n14 parseInt(document.getElementById('reservas_lucros_realizar').value);
	var reservas_capital= n12 + n13 + n14;
	document.getElementById('reservas_capital').value = reservas_capital;

	var passivo_circulante = obrigacoes_fornecedores + emprestimos_financiamentos+ tributos_recolher + otp + pdll + outras_obrigacoes;
	document.getElementById('passivo_circulante').value = passivo_circulante;

	var patrimonio_liquido = capital_social + reservas_capital;
	document.getElementById('patrimonio_liquido').value = patrimonio_liquido;

	var total_passivo = passivo_circulante + patrimonio_liquido;
	document.getElementById('total_passivo').value = total_passivo;	
}